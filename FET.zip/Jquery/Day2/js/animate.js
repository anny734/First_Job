$(document).ready(
    ()=>{
        $('#one').click(
            ()=>{
                $('p').animate({width:"100%"}).animate({fontSize:
                    "46px"}).animate({borderWidth:30}).animate({opacity: "0.2"});
            }
        );
        $('#b1').click(
            ()=>{
                $('div').slideUp(1000);
            }
        );
        $('#b2').click(
            ()=>{
                $('div').slideDown(1000);
            }
        );
        $('#b3').click(
            ()=>{
                $('div').fadeIn(2000,()=>{
                    alert("Fade in completed")
                });
            }
        );
        $('#b4').click(
            ()=>{
                $('div').fadeOut(2000);
            }
        );




    }

);