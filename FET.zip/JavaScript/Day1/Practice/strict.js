"use strict";
x=3.14; // not allowed

"use strict";
var x=3.14;
delete x; // not allowed

function fun(x,x){
    console.log("done")
} // in normal allowed but in strict not allowed bcoz same name of 2 variables

"use strict";
function fun(x,x){
    console.log("done")
} // not allowed

//octal numeric literals are not allowes;
"use strict";
var x = 010;

//Escape characters are not allowed
"use strict";

//property 
var emp = {emp_id:101,empName:"John",empSalary:"1Cr",jdate:new Date()}

var emp = {emp_id:101,empName:"John",empSalary:"1Cr",contact:['9211','1212','3223']}

var emp = {emp_id:101,empName:{fname:"ankit",lname:"sonje"},empFullname:()=>{
    return emp.empName.fname+" "+emp.empName.lname},eDesig:"CEO",empSalary:"1Cr",contact:['9211','1212','3223']}


    var emp = {emp_id:101,empName:{fname:"ankit",lname:"sonje"},empFullname:()=>{
        console.log(emp.empName.fname+" "+emp.empName.lname)}}
    
        var emp = {emp_id:101,empName:{fname:"ankit",lname:"sonje"},empFullname:function()=>{
            console.log(this.empName.fname+" "+this.empName.lname)}}

//comstructor function
function employee(){
    this.enam="ankit";this.empid=101;}
var emp1 = new employee()
emp1 // has the details

    function employee(ename,empid){
        this.enam=ename;this.empid=empid;}
    var emp2 = new employee('Thanos',101)
    emp2 // has the details




