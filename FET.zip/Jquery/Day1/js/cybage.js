$(document).ready(
    ()=>{
        $('button').click(
            ()=>{
                $('footer').html("Cybage.com, Pune");
                $('body').css('background-color',' rgb(240, 186, 115)');
                $('#one').html("Welcome to Cybage Website");
                $('#one').css('background-color','green');












            }
        );
        
    




















    }
);