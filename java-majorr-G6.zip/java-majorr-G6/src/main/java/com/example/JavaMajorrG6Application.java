package com.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Profile;
import com.example.entity.User;
import com.example.repositiories.ProfileRepo;
import com.example.repositiories.UserRepo;

@SpringBootApplication
public class JavaMajorrG6Application {

	
	public static void main(String[] args) {
		SpringApplication.run(JavaMajorrG6Application.class, args);
	}


}
