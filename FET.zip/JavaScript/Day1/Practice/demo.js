var num = prompt("Enter any number");
for(i=1;i<=10;i++){
    document.writeln(num+"*"+[i]+"="+num*[i]+"</br>");
    
}




