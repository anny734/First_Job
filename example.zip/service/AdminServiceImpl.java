package com.example.service;

public class AdminServiceImpl implements AdminService{

}
