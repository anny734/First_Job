

function seeMenu() {
    
    document.getElementById("mainText").innerHTML = "We have alot of menus like 1) Iddli Sambar 2) Dosa 3) Vada Pav";

}
function seeVendor() {
    document.getElementById("mainText").innerHTML = "Our Vendors are 1) Ganesh Chaudhary and 2) Amit Singh";
}
function seeTestimonials() {
    document.getElementById("mainText").innerHTML = "For now we don't have any testimonials <br>but if want to submit yours please feel free to connect with us. ";
}