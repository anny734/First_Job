function add_book() {
    
    document.getElementById("title").innerHTML = "<h1>Add Book Details</h1>";
    document.getElementById("desc").innerHTML = "<div class=col-lg-6>Book Name:<input type=text name=book_nm ></div><br><div class=col-lg-6>Book Description:<textarea name=book_desc rows=5  cols=15></textarea></div><br><div class=col-lg-6>Book Price:<input type=text name=book_price ></div><br><div class=col-lg-6><input type=submit name=submit value=Add_Book style=align:center ></div><br>";
}   

function view_books() {
    document.getElementById("title").innerHTML = "<h1>All Books Details</h1>";
    document.getElementById("desc").innerHTML = "<table border=1><thead><tr><th>Select</th><th>Book Name:</th><th>Book_description</th><th>Book_price</th></tr></thead><tbody><tr><td><input type=checkbox name=select ></td><td>abc</td><td>fshfjhsgnagxj</td><td>500 rs.</td></tr><tr><td><input type=checkbox name=select ></td><td>mno</td><td>fshfjhsgnagxj</td><td>400 Rs.</td</tr><tr><td><input type=checkbox name=select ></td><td>xyz</td><td>fshfjhsgnagxj</td><td>900 Rs.</td></tr></tbody></table>";
 }
 function update_book() {
    
    document.getElementById("title").innerHTML = "<h1>Edit Book Details</h1>";
    document.getElementById("desc").innerHTML = "<div class=col-lg-6>Book Name:<input type=text name=book_nm ></div><br><div class=col-lg-6>Book Description:<textarea name=book_desc rows=5  cols=15></textarea></div><br><div class=col-lg-6>Book Price:<input type=text name=book_price ></div><br><div class=col-lg-6><input type=submit name=submit value=Update_Book style=align:center ></div><br>";
}   
function remove_books() {
    document.getElementById("title").innerHTML = "<h1>All Books Details</h1>";
    document.getElementById("desc").innerHTML = "<table border=1><thead><tr><th>Select</th><th>Book Name:</th><th>Book_description</th><th>Book_price</th></tr></thead><tbody><tr><td><input type=checkbox name=select ></td><td>abc</td><td>fshfjhsgnagxj</td><td>500 rs.</td></tr><tr><td><input type=checkbox name=select ></td><td>mno</td><td>fshfjhsgnagxj</td><td>400 Rs.</td</tr><tr><td><input type=checkbox name=select ></td><td>xyz</td><td>fshfjhsgnagxj</td><td>900 Rs.</td></tr><tr><td colspan=4><input type=submit name=submit value=Delete_Books style=align:center ></td></tr></tbody></table>";
 }
 function contact() {
    document.getElementById("title").innerHTML = "<h1>Contact for Registration</h1>";
    document.getElementById("desc").innerHTML = "<div><i class=fa fa-phone-square aria-hidden=true ></i>&nbsp;<br></div><div><i class=fa fa-envelope aria-hidden=true ></i>&nbsp;<br></div><div><i class=fa fa-facebook-square aria-hidden=true ></i>&nbsp;<br></div><div><i class=fa fa-twitter-square aria-hidden=true ></i>&nbsp;<br></div>";
 }
 function contact1() {
    document.getElementById("title").innerHTML = "<h1>Contact for Registration</h1>";
    document.getElementById("desc").innerHTML = "<div><b>Mo.</b>:  0123456789</div><br><div><b>Email: </b> abc@hjg.in</div><br><div><b>Facebook:</b> https://www.facebook.com</div><br><div><b>Titter: </b>https://www.twitter.com</div>";
 }
