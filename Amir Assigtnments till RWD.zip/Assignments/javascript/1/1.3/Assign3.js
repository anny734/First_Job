function sayHello(){
    alert("Hii");
    return "Helllo from javascript";
}