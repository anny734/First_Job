// GET call

// $(document).ready(
//     ()=>{
//         $.ajax({
//             url:"https://reqres.in/api/users/6",
//             method:"GET",
//             success:(x)=>{
//                 console.log("data :",x);

//                 $("span#one").append(x.data.first_name+" "+x.data.last_name);
//                 $("span#two").append(x.data.email);
//                 var img= x.data.avatar;
//                 var drawing="<img src='"+img+"'/>";
//                 $('span#three').append(drawing);
//             },
//             error:(e)=>{
//                 alert("Sometthing went wrong "+e);

//             }

//         });
//     }
// );


// show all the users 

$(document).ready(
    ()=>{
        $.ajax({
            url:"https://reqres.in/api/users/",
            method:"GET",
            success:(x)=>{
                console.log("data :",x);
                var i;
                // console.log(x.data.length);
                // for(i=0;i<x.data.length;i++)
                // {
                //     console.log(x.data[i].id);
                //     $("span#one").append(x.data[i].first_name+" "+x.data[i].last_name+"<br>");
                //     $("span#two").append(x.data[i].email+"<br>");
                //     var img= x.data[i].avatar;
                //     var drawing="<img src='"+img+"'/>";
                //     $('span#three').append(drawing);
                // }
                $.each(x.data,function(){
                    console.log("id:"+x.data.id);
                });
                
            },
            error:(e)=>{
                alert("Sometthing went wrong "+e);

            }

        });
    }
);

// POST call
// $(document).ready(
//     ()=>{
//         $.ajax({
//             url:"https://reqres.in/api/users/6",
//             method:"POST",
//             data:{
//                 "name":"samueal", "job":"CEO"
//             },
//             success:(x)=>{
//                 alert(x.name+" user posted ");
//                 console.log("data :",x);

//             },
//             error:(e)=>{
//                 alert("Sometthing went wrong "+e);

//             }

//         });
//     }
// );