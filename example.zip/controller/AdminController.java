package com.example.controller;

public class AdminController {

}
