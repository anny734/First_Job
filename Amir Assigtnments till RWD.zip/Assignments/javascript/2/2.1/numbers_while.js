var i =1;
while (i<=100) {
    document.write(i+" ");
    if(i%10==0){
        document.write('<br></br>');
    }
    i++
}
