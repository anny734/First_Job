package com.example.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Profile;
import com.example.entity.User;
import com.example.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserService us;

	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
	public String createUser(@RequestBody User user) {
		return us.createUser(user);
	}
	
	@GetMapping
	@ResponseStatus(code = HttpStatus.FOUND)
	public User forLogin(@RequestBody User user) {
		return us.forLogin(user.getUsername(), user.getEmail(), user.getPassword());
	}
	
	
	@GetMapping("/{id}")
	@ResponseStatus(code = HttpStatus.FOUND)
	public Optional<User> getuserDetails(@PathVariable int id) {
		return us.getuserDetails(id);
	}
	
	@GetMapping("/{id}/{password}")
	@ResponseStatus(code = HttpStatus.FOUND)
	public String getPassword(@PathVariable int id,@PathVariable String password) {
		return us.getPassword(id, password);
	}
	
	@PutMapping("/update")
	@ResponseStatus(code = HttpStatus.CREATED)
	public String editProfile(@RequestBody User user) {
		return us.editUserDetails(user);
	}
	
	@PutMapping("/password") // we will take whole object of user first in UI then will send the updated object 
	public User changePassword(@RequestBody User user) {
		return us.changePassword(user);
	}
	
	@GetMapping("/email/{email}")
	public String getEmailSendTempPass(@PathVariable String email) {
		return us.getEmailSendTempPass(email);
	}
	
	@GetMapping("/username/{username}")
	public String checkUsername(@PathVariable String username) {
		return us.checkUsername(username);
	}
	
	@PostMapping("/profile/{userid}") //we have send userid while creating profile
	@ResponseStatus(code = HttpStatus.CREATED)
	public Profile createProfile(@PathVariable int userid,@RequestBody Profile profile) {
		return us.createProfile(userid, profile);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteUser(@PathVariable int id) {
		return us.deleteUser(id);
	}
	
	@GetMapping("/profile/{userid}")
	public Profile getProfileDetails(@PathVariable int userid) {
		return us.getProfileDetails(userid);
	}
	
	@PutMapping("/profile/{userid}")
	public Profile editProfile(@PathVariable int userid, @RequestBody Profile profile) {
		return us.editProfile(userid, profile);
	}
}
