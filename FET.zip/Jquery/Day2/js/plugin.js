$(document).ready(
    ()=>{
        $('.slideshow').cycle({
            // fx:'shuffle',
            
            // delay:-100
        });
    }
);