var i =1;
do {
    
    document.write(i+" ");
    if(i%10==0){
        document.write('<br></br>');
    }
    i++

} while (i<=100);
