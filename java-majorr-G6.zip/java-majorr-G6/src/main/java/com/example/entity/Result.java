package com.example.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Result {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int resultID;
	private int userID;
	private int courseID;
	
//		@OneToOne(fetch = FetchType.LAZY,
//
//				cascade = CascadeType.ALL, mappedBy = "result")
//		private User user;
				
//				@OneToOne(fetch = FetchType.LAZY,
			//
//						cascade = CascadeType.ALL, mappedBy = "result")
//				private Course course;
	
}
