function sayHello(lang){
    var text ="Talk" + lang; // local variable

    var sayAlert = function(fluency){
        if(fluency ===1)
        console.log("Begineer"+text);
        else 
        console.log("Expert"+text);
    }

    return sayAlert;
}
var talkHindi = sayHello("Hindi");
talkHindi(1);
talkHindi(3);
talkHindi(43);
var talkMarathi  = sayHello("Marathi");
talkMarathi(1);
var talkEng = sayHello("English");
talkEng(2);

//example 2
function setupSomeGlobals(){
    // local varibales that ends up within closure
    var num  = 666;
    
    //Store some references to function as global variables
    gAlertNumber = function(){alert(num);}
    gIncreaseNumber = function(){num++;}
    gSetNumber = function(x){num =x;}
}

setupSomeGlobals() // value of num 666
gAlertNumber() //alerts 666
gIncreaseNumber()

gAlertNumber() //alerts 667
gSetNumber(600)
gAlertNumber()// alerts 600

// IIFE module
var Module = (function(){
    var x=89;
    function privateMethod(){
        //private data
        console.log('inside private method...')
    }
    return{
        publicMethod : function(){
            // can call privateMEthod();
            privateMethod();
            console.log(x);
        }
    };

})();
// Module.publicMethod() is accessible while 
//Module.privateMethod is not accesible

// prototype example
var fruits =['guava','watermelon','kiwi'];
Object.defineProperty(Array.prototype,'last',
    {get:function(){return this[this.length-1];}});

console.log(fruits.last);

//example
function Cat(name , color){
    this.name = name;
    this.color = color;
}
var fluffy = new Cat("fluffy","white");
   // see answer for fluffy.age
Cat.prototype.age = 3;
 // we can also change the value of age to particular var 
  // example fluffy.age = 10;
var muffin = new Cat("muffin","grey");
muffin.age

Cat.prototype = {age: 20} // changing protoptype
// from above step the newer objects will have age as 20 
var bella = new Cat("bella","brown");
bella.age // answer will be 20