package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaMajorrG6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
