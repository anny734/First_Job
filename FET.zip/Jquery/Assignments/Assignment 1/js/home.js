$(document).ready(
    ()=>{
        $.ajax({
            url:"https://jsonplaceholder.typicode.com/photos",
            method: "GET",
            success:(x)=>{

                x.forEach(data=>{
                    var name=data.title;
                    var img= data.thumbnailUrl;
                    var card = `<div id='inrBox'>
                    <img src="${img}" alt="" height="100px" width="100px"/>
                    <p>${name.substring(0,25)}</p>
                    <button>add to cart</button>
                    </div>`;
                    $('#Box').append(card);
                });                






               // console.log(JSON.stringify(x));
                // x.forEach(data =>{
                //     console.log(JSON.stringify(data));
                //     $('#Box').append("<div id='inrBox'></div>");
                //     var img= data.thumbnailUrl;
                //     var drawing="<img src='"+img+"'/>";
                //     $('#inrBox').append(drawing);
                //     $("#inrBox").append(data.title);
                //     $("#inrBox").append("<button class='cart'>add to cart</button>");
                // }
                    
                // );
                
            },
            error:(e)=>{
                alert("Something went wrong",e);
            }
        });

        
    }
);