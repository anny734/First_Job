$(document).ready(
    // function(){
    //     alert("JQuery is ready")
    // }
    ()=>{
        //alert('jQuery is working fine');

        $("div").click(
            ()=>{
                console.log("You clicked on division tag");
            }
        );
        // console.log($(document));

        $('#myButton').click(
            ()=>{
                // alert("u clicked on a button")
                $('div#divone').css('color','cyan');
                $('div#divone').height('100px');
                $('div#divone').width('100px');
                $('div:even').addClass('myClass'); //adding new class and also we have css for that
            }
        );

         

        var allP = $('section').find('p');
        console.log("find method ",allP)
        var childP = $('section').children('p');
        console.log("children method ",childP);

       
        console.log($('div#divone').css('color'));

        

        var jqinput = $('input[class^="fname"]');
        console.log("This in input tag starting with used in it for attribute selection",jqinput);
        var jqinput2 = $('input[class$="name"]');
        console.log("This in input tag",jqinput2);
        var jqdiv = $('div[id="divone"]');
        console.log("this is equal to ",jqdiv);

        var allDivs=$('div');
        console.log(allDivs);
        var divwithId=$('#divone');
        console.log(divwithId);
        var divwithclass=$('.odd');
        console.log(divwithclass);
        var divwithtwoclass=$('.odd.even');
        console.log(divwithtwoclass);
        var evendiv=$('div:even');
        console.log("even div",evendiv);
            
            

    }
    
);

