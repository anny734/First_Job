function addNumbers1(i,j){
document.write("addition of "+i+" and "+j+" is "+(i+j));
}