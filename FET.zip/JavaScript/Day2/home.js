"use strict";
var cat = {
    name :{fname:"Fulffy",lname:"Suzen"},
    color : "Brown"
}
Object.getOwnPropertyDescriptor(cat,'name');
Object.defineProperty(cat,'name',{enumerable:false});
for(var prop in cat){
    console.log(prop+" : "+cat[prop])
} //hence the fname and lname is not displayed


// getter and setter 
var person ={
    fname:"Ajay",lname:"devgan",
    get fullName(){
        return this.fname+" "+this.lname;
    },
    set fullName(name){
        var words = name.toString().split(" ");
        this.fname= words[0] || " ";
        this.lname= words[1] || " ";

    }
}
person.fullName = "Aman Shah";
console.log(person.fname);
console.log(person.lname);

// class
class Employee{
    constructor(){
        this.salary="100k";
    }
}
Employee
var e1 = new Employee();

// parametarized
class Employee{
    constructor(salary){
        this.salary=salary;
    }
}
var e1 = new Employee("50k");

//  class with functions
class Place{
    constructor()
    {
        this.place="pune";
    }
    myPlace(){
        this.place="Dhule";
    }
    extra(place){
        this.place=place;
    }
    display(){
        console.log(this.place);
    }
      
}
var e1 = new Place();

// scopes
myFunc();
console.log(carName);
     // variable hoisting happens at the backend
function myFunc(){
    carName = "volvo";
}

// object methods
const place = {
    name: "pune"
  };
  
  Object.freeze(place);
  
  place.name = "mumbai";
  // Throws an error in strict mode
  
  console.log(place.name);
  // expected output: 42
  
  Object.seal(place);
  delete place.name;
  console.log(place.name);

  const target = { a: 1, b: 2 };
const source = { b: 4, c: 5 };

const returnedTarget = Object.assign(target, source);

console.log(target);
// expected output: Object { a: 1, b: 4, c: 5 }

console.log(returnedTarget);
// expected output: Object { a: 1, b: 4, c: 5 }
