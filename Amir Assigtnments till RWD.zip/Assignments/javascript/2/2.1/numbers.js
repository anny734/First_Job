for (var i = 1; i <= 100; i++) {
      document.write(i+" ");
      if(i%10==0){
          document.write('<br></br>');
      }
}
